-- MySQL dump 10.13  Distrib 8.0.20, for Win64 (x86_64)
--
-- Host: localhost    Database: facturacionvirtual
-- ------------------------------------------------------
-- Server version	8.0.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` VALUES (1,'Can add log entry',1,'add_logentry'),(2,'Can change log entry',1,'change_logentry'),(3,'Can delete log entry',1,'delete_logentry'),(4,'Can view log entry',1,'view_logentry'),(5,'Can add permission',2,'add_permission'),(6,'Can change permission',2,'change_permission'),(7,'Can delete permission',2,'delete_permission'),(8,'Can view permission',2,'view_permission'),(9,'Can add group',3,'add_group'),(10,'Can change group',3,'change_group'),(11,'Can delete group',3,'delete_group'),(12,'Can view group',3,'view_group'),(13,'Can add content type',4,'add_contenttype'),(14,'Can change content type',4,'change_contenttype'),(15,'Can delete content type',4,'delete_contenttype'),(16,'Can view content type',4,'view_contenttype'),(17,'Can add session',5,'add_session'),(18,'Can change session',5,'change_session'),(19,'Can delete session',5,'delete_session'),(20,'Can view session',5,'view_session'),(21,'Can add usuario',6,'add_usuariomodel'),(22,'Can change usuario',6,'change_usuariomodel'),(23,'Can delete usuario',6,'delete_usuariomodel'),(24,'Can view usuario',6,'view_usuariomodel'),(25,'Can add Comprobante',7,'add_comprantemodel'),(26,'Can change Comprobante',7,'change_comprantemodel'),(27,'Can delete Comprobante',7,'delete_comprantemodel'),(28,'Can view Comprobante',7,'view_comprantemodel'),(29,'Can add Mesa',8,'add_mesamodel'),(30,'Can change Mesa',8,'change_mesamodel'),(31,'Can delete Mesa',8,'delete_mesamodel'),(32,'Can view Mesa',8,'view_mesamodel'),(33,'Can add Detalle',9,'add_detallecomandamodel'),(34,'Can change Detalle',9,'change_detallecomandamodel'),(35,'Can delete Detalle',9,'delete_detallecomandamodel'),(36,'Can view Detalle',9,'view_detallecomandamodel'),(37,'Can add Comanda',10,'add_cabeceracomandamodel'),(38,'Can change Comanda',10,'change_cabeceracomandamodel'),(39,'Can delete Comanda',10,'delete_cabeceracomandamodel'),(40,'Can view Comanda',10,'view_cabeceracomandamodel'),(41,'Can add Inventario',11,'add_inventariomodel'),(42,'Can change Inventario',11,'change_inventariomodel'),(43,'Can delete Inventario',11,'delete_inventariomodel'),(44,'Can view Inventario',11,'view_inventariomodel');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-02-10 18:47:55
