-- MySQL dump 10.13  Distrib 8.0.20, for Win64 (x86_64)
--
-- Host: localhost    Database: facturacionvirtual
-- ------------------------------------------------------
-- Server version	8.0.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `django_migrations`
--

LOCK TABLES `django_migrations` WRITE;
/*!40000 ALTER TABLE `django_migrations` DISABLE KEYS */;
INSERT INTO `django_migrations` VALUES (1,'contenttypes','0001_initial','2021-02-03 19:09:53.203910'),(2,'contenttypes','0002_remove_content_type_name','2021-02-03 19:09:53.336580'),(3,'auth','0001_initial','2021-02-03 19:09:53.429566'),(4,'auth','0002_alter_permission_name_max_length','2021-02-03 19:09:53.800228'),(5,'auth','0003_alter_user_email_max_length','2021-02-03 19:09:53.805228'),(6,'auth','0004_alter_user_username_opts','2021-02-03 19:09:53.812004'),(7,'auth','0005_alter_user_last_login_null','2021-02-03 19:09:53.817011'),(8,'auth','0006_require_contenttypes_0002','2021-02-03 19:09:53.821014'),(9,'auth','0007_alter_validators_add_error_messages','2021-02-03 19:09:53.827012'),(10,'auth','0008_alter_user_username_max_length','2021-02-03 19:09:53.833014'),(11,'auth','0009_alter_user_last_name_max_length','2021-02-03 19:09:53.839013'),(12,'auth','0010_alter_group_name_max_length','2021-02-03 19:09:53.853012'),(13,'auth','0011_update_proxy_permissions','2021-02-03 19:09:53.859013'),(14,'auth','0012_alter_user_first_name_max_length','2021-02-03 19:09:53.866043'),(15,'Facturacion','0001_initial','2021-02-03 19:09:53.966012'),(16,'admin','0001_initial','2021-02-03 19:09:54.390330'),(17,'admin','0002_logentry_remove_auto_add','2021-02-03 19:09:54.691410'),(18,'admin','0003_logentry_add_action_flag_choices','2021-02-03 19:09:54.698379'),(19,'sessions','0001_initial','2021-02-03 19:09:54.745102'),(20,'Facturacion','0002_auto_20210203_1918','2021-02-03 19:18:15.729208'),(21,'Facturacion','0003_auto_20210203_1918','2021-02-03 19:18:38.320914'),(22,'Facturacion','0004_auto_20210203_1919','2021-02-03 19:20:04.141885'),(23,'Facturacion','0005_auto_20210203_1920','2021-02-03 19:20:55.220184'),(24,'Almacen','0001_initial','2021-02-03 20:48:37.532296'),(25,'Facturacion','0006_auto_20210203_2048','2021-02-03 20:48:37.852360'),(26,'Almacen','0002_auto_20210204_1911','2021-02-04 19:13:11.406685');
/*!40000 ALTER TABLE `django_migrations` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-02-06  8:07:52
